package classes;

import interfaces.Descriavel;

public class Computador extends Produto {
    private ComponenteComputador processador;
    private ComponenteComputador memoriaRam;
    private ComponenteComputador armazenamento;

    public Computador(String nome, double preco, ComponenteComputador processador, ComponenteComputador memoriaRam, ComponenteComputador armazenamento) {
        super(nome, preco);
        this.processador = processador;
        this.memoriaRam = memoriaRam;
        this.armazenamento = armazenamento;
    }

    @Override
    public void descricaoDetalhada() {
        System.out.println("Computador: " + getNome() + " - " +
                ((Descriavel) processador).descricaoComponente() + ", " +
                ((Descriavel) memoriaRam).descricaoComponente() + ", " +
                ((Descriavel) armazenamento).descricaoComponente());
    }
}
