
 
package classes;

import interfaces.Descriavel;




public class MemoriaRam extends ComponenteComputador implements Descriavel {
    public MemoriaRam(int capacidadeGB, String tipo) {
        super(capacidadeGB, tipo);
    }

    @Override
    public String descricaoComponente() {
        return "Memória RAM: " + getCapacidadeGB() + "GB " + getTipo();
    }
}

