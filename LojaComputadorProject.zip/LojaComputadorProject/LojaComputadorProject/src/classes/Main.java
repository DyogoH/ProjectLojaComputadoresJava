/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

/**
 *
 * @author dyogo
 */
public class Main {
    public static void main(String[] args) {
        Processador processador = new Processador("Intel Core i7", 3.5);
        MemoriaRam memoriaRam = new MemoriaRam(16, "DDR4");
        Armazenamento armazenamento = new Armazenamento(512, "SSD");

        Computador computador = new Computador("Desktop Gamer", 3500.0, processador, memoriaRam, armazenamento);

        computador.descricaoDetalhada();
    }
}



